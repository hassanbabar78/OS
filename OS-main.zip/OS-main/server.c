
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pthread.h>
#include <ctype.h>
#include <stdbool.h>

#define PORT 14000
#define STORAGE_LIMIT 1000000000 // 10 KB storage limit per client

//////////////////new code

void Wait(int *s)
{
    while (*s <= 0)
        ;   // Busy-wait until semaphore is greater than 0
    (*s)--; // Decrement the semaphore
}

// Signal(S) function (V operation)
void Signal(int *s)
{
    (*s)++; // Increment the semaphore
}

#define MAX_USERS 10
#define MAX_QUEUE_SIZE 10

typedef struct
{
    int wrt;                   // Write semaphore
    int readcount;             // Read counter
    int mutex;                 // Mutex for synchronization
    char name[100];            // Name string (could be file or other entity name)
    char username[100];        // Username string
    int queue[MAX_QUEUE_SIZE]; // Array of integers for queued users (changed from string array)
} Filedetails;

// Global array of structs
Filedetails filesarray[MAX_USERS];
int filesCount = 0; // Keeps track of the number of files/details added
int findFile(const char *fileName, const char *userName)
{
    for (int i = 0; i < filesCount; i++)
    {
        if (strcmp(filesarray[i].name, fileName) == 0 && strcmp(filesarray[i].username, userName) == 0)
        {
            return i; // Return the index of the found file
        }
    }
    return -1; // Return -1 if no match is found
}
// Function to push FileDetails into the array
void pushFiledetails(const char *name, const char *username)
{
    // Ensure we don't exceed MAX_USERS
    if (filesCount >= MAX_USERS)
    {
        printf("Error: Maximum file details limit reached.\n");
        return;
    }

    // Initialize the new Filedetails struct
    filesarray[filesCount].wrt = 1;
    filesarray[filesCount].readcount = 0;
    filesarray[filesCount].mutex = 1;

    // Set the name and username
    strncpy(filesarray[filesCount].name, name, sizeof(filesarray[filesCount].name) - 1);
    filesarray[filesCount].name[sizeof(filesarray[filesCount].name) - 1] = '\0'; // Null-terminate the string

    strncpy(filesarray[filesCount].username, username, sizeof(filesarray[filesCount].username) - 1);
    filesarray[filesCount].username[sizeof(filesarray[filesCount].username) - 1] = '\0'; // Null-terminate the string

    // Initialize the queue (empty initially, setting to 0 or any default integer)
    for (int i = 0; i < MAX_QUEUE_SIZE; i++)
    {
        filesarray[filesCount].queue[i] = 0; // Set all entries in the queue to 0 (or any other default integer)
    }

    // Increment the file count
    filesCount++;

    printf("FileDetails for user '%s' added successfully.\n", username);
}

// Function to print the details of all files in the array
void printFilesArray()
{
    if (filesCount == 0)
    {
        printf("No file details available.\n");
        return;
    }

    printf("FilesArray Contents:\n");
    for (int i = 0; i < filesCount; i++)
    {
        printf("Index %d:\n", i);
        printf("  Name       : %s\n", filesarray[i].name);
        printf("  Username   : %s\n", filesarray[i].username);
        printf("  wrt        : %d\n", filesarray[i].wrt);
        printf("  readcount  : %d\n", filesarray[i].readcount);
        printf("  mutex      : %d\n", filesarray[i].mutex);
        printf("  Queue      : ");

        // Print queue integers
        for (int j = 0; j < MAX_QUEUE_SIZE; j++)
        {
            if (filesarray[i].queue[j] != 0)
            { // Only print non-zero entries (or change condition as needed)
                printf("%d ", filesarray[i].queue[j]);
            }
        }
        printf("\n");
    }
}

//////////////added code

#define MAX_ENTRIES 100 // Maximum number of username-password pairs
#define MAX_LENGTH 50   // Maximum length of each username/password

typedef struct
{
    char username[MAX_LENGTH];
    char password[MAX_LENGTH];
} User;
struct client_info
{
    int used_space;
} client;

#include <dirent.h>
#include <sys/stat.h>
#include <time.h>

void handle_view(int new_socket, const char *username)
{
    char dir[1024];
    snprintf(dir, sizeof(dir), "./server_dir/%s", username); // Construct path to user's directory

    DIR *d;
    struct dirent *dir_entry;
    struct stat file_stat;
    char file_info[1024] = {0};
    char buffer[1024] = {0};

    // Open the directory
    if ((d = opendir(dir)) == NULL)
    {
        send(new_socket, "$FAILURE$NO_CLIENT_DATA$", strlen("$FAILURE$NO_CLIENT_DATA$"), 0);
        return;
    }

    int has_files = 0;

    // Read through the directory entries
    while ((dir_entry = readdir(d)) != NULL)
    {
        // Skip "." and ".." entries
        if (strcmp(dir_entry->d_name, ".") == 0 || strcmp(dir_entry->d_name, "..") == 0)
            continue;

        has_files = 1; // Mark that there is at least one file

        // Get the full file path
        char full_path[9999];
        snprintf(full_path, sizeof(full_path), "%s/%s", dir, dir_entry->d_name);

        // Get file statistics
        if (stat(full_path, &file_stat) == 0)
        {
            // File name
            snprintf(buffer, sizeof(buffer), "Name: %s, ", dir_entry->d_name);
            strcat(file_info, buffer);

            // File size
            snprintf(buffer, sizeof(buffer), "Size: %ld bytes, ", file_stat.st_size);
            strcat(file_info, buffer);

            // Last modified time
            struct tm *timeinfo = localtime(&file_stat.st_mtime);
            char time_buf[64];
            strftime(time_buf, sizeof(time_buf), "%Y-%m-%d %H:%M:%S", timeinfo);
            snprintf(buffer, sizeof(buffer), "Last Modified: %s\n", time_buf);
            strcat(file_info, buffer);
        }
    }
    closedir(d);

    if (has_files)
    {
        send(new_socket, file_info, strlen(file_info), 0);
    }
    else
    {
        send(new_socket, "$FAILURE$NO_CLIENT_DATA$", strlen("$FAILURE$NO_CLIENT_DATA$"), 0);
    }
}
void handle_upload(int new_socket, char *command, const char *username)
{
    char *file_path = strtok(command, "$");
    file_path = strtok(NULL, "$");

    // Check if the client has enough space
    if (client.used_space >= STORAGE_LIMIT)
    {
        send(new_socket, "$FAILURE$LOW_SPACE$", strlen("$FAILURE$LOW_SPACE$"), 0);
        return;
    }

    send(new_socket, "$SUCCESS$", strlen("$SUCCESS$"), 0);

    // Extract the base file name from the full file path
    char *base_name = strrchr(file_path, '/');
    if (!base_name)
    {
        base_name = file_path; // No '/' found, use the full path as the name
    }
    else
    {
        base_name++; // Skip the '/'
    }

    // Find the file index for the file
    int index = findFile(base_name, username);

    // If the file is found, apply wait and signal
    bool file_found = (index != -1);

    if (file_found)
    {
        // If file is found, apply Wait to ensure no other writer is active
        Wait(&(filesarray[index].wrt));
        printf("Sleeping for 10 seconds...\n");
        sleep(10); // Sleep for 10 seconds

        // Debug: Check if sleep is reached
        printf("Woke up from sleep!\n");
    }
    

    // Create the directory for the user
    char dir[1024];
    snprintf(dir, sizeof(dir), "./server_dir/%s", username);
    mkdir(dir, 0777); // Create the directory for the user

    char full_path[9999];
    snprintf(full_path, sizeof(full_path), "%s/%s", dir, base_name);

    // Open the file for writing (or create it if it doesn't exist)
    FILE *file = fopen(full_path, "wb");
    if (!file)
    {
        perror("File open failed");

        // If file couldn't be opened or created, release the lock if any
        if (file_found)
        {
            Signal(&(filesarray[index].wrt));
        }
        return;
    }

    // Read the file data from the socket and write it to the server's file
    char buffer[1024];
    int bytes_read;
    while ((bytes_read = read(new_socket, buffer, sizeof(buffer))) > 0)
    {
        fwrite(buffer, 1, bytes_read, file);
        client.used_space += bytes_read;

        // If storage limit is exceeded, stop the upload
        if (client.used_space >= STORAGE_LIMIT)
        {
            send(new_socket, "$FAILURE$LOW_SPACE$", strlen("$FAILURE$LOW_SPACE$"), 0);
            break;
        }
    }

    fclose(file);

    // After finishing the upload, send success to the client
    send(new_socket, "$SUCCESS$", strlen("$SUCCESS$"), 0);

    // Release the lock if the file was found
    if (file_found)
    {
        Signal(&(filesarray[index].wrt));
    }

    // Optionally, add the file to the list if it was a new file
    if (!file_found)
    {
        pushFiledetails(base_name, username);
    }

    // Print the file details array (optional, for debugging purposes)
    printFilesArray();
}


void handle_download(int new_socket, char *command, const char *username)
{
    // Parse the command to extract the file name
    char *file_name = strtok(command, "$");
    file_name = strtok(NULL, "$");

    if (!file_name) {
        // Send failure response if file name is not provided
        send(new_socket, "$FAILURE$INVALID_COMMAND$", strlen("$FAILURE$INVALID_COMMAND$"), 0);
        return;
    }

    // Construct the full path to the file based on the username and file name
    char full_path[1024];
    snprintf(full_path, sizeof(full_path), "./server_dir/%s/%s", username, file_name);

    // Locate the file in the files array
    int index = findFile(file_name, username);
    if (index == -1) {
        // If the file is not found, notify the client
        send(new_socket, "$FAILURE$FILE_NOT_FOUND$", strlen("$FAILURE$FILE_NOT_FOUND$"), 0);
        return;
    }

    // Apply reader-writer synchronization
    Wait(&(filesarray[index].mutex));
    filesarray[index].readcount++;
    if (filesarray[index].readcount == 1) {
        Wait(&(filesarray[index].wrt)); // First reader locks the writer
    }
    Signal(&(filesarray[index].mutex));

    // Try to open the file in read mode
    FILE *file = fopen(full_path, "rb");
    if (!file) {
        // Notify client of failure to open the file
        Wait(&(filesarray[index].mutex));
        filesarray[index].readcount--;
        if (filesarray[index].readcount == 0) {
            Signal(&(filesarray[index].wrt)); // Last reader releases the writer lock
        }
        Signal(&(filesarray[index].mutex));

        send(new_socket, "$FAILURE$FILE_NOT_FOUND$", strlen("$FAILURE$FILE_NOT_FOUND$"), 0);
        return;
    }

    // Notify the client of successful file readiness
    send(new_socket, "$SUCCESS$", strlen("$SUCCESS$"), 0);

    // Introduce a small delay to allow the client to process the success message
    usleep(100000); // 100ms delay to ensure the client reads $SUCCESS$ before file data

    // Read the file and send it to the client in chunks
    char buffer[1024];
    int bytes_read;
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        if (send(new_socket, buffer, bytes_read, 0) == -1) {
            perror("Error sending file content");
            break; // Stop if sending fails
        }
    }

    fclose(file);

    // Reader finished, update the read count and possibly unlock the writer
    Wait(&(filesarray[index].mutex));
    filesarray[index].readcount--;
    if (filesarray[index].readcount == 0) {
        Signal(&(filesarray[index].wrt)); // Last reader unlocks the writer
    }
    Signal(&(filesarray[index].mutex));

    // Signal EOF to the client and close the connection
    shutdown(new_socket, SHUT_WR);
}


bool complete_database(const char *username)
{
    printf("Searching for username: %s\n", username);
    FILE *file = fopen("database.txt", "r"); // Open in "r" mode for text reading
    if (file == NULL)
    {
        perror("Error opening file");
        return false; // Return false as an indication of error
    }

    User users[MAX_ENTRIES];
    int count = 0;
    char line[1024];

    // Read each line from the file
    while (fgets(line, sizeof(line), file) != NULL && count < MAX_ENTRIES)
    {
        // Remove the newline character at the end of the line, if it exists
        line[strcspn(line, "\n")] = 0;

        // Split the line into username and password using ':' and ';'
        char *file_username = strtok(line, ":"); // Use a unique name for clarity
        char *password = strtok(NULL, ";");

        if (file_username && password)
        {
            strncpy(users[count].username, file_username, MAX_LENGTH - 1);
            users[count].username[MAX_LENGTH - 1] = '\0'; // Null-terminate
            strncpy(users[count].password, password, MAX_LENGTH - 1);
            users[count].password[MAX_LENGTH - 1] = '\0'; // Null-terminate
            count++;
        }
    }

    fclose(file);

    // Check if the specified username exists in the array
    for (int i = 0; i < count; i++)
    {
        printf("Username: %s, Password: %s\n", users[i].username, users[i].password);
        if (strcmp(username, users[i].username) == 0)
        { // Use strcmp to compare strings
            return true;
        }
    }
    return false;
}

void add_user(const char *username, const char *password)
{
    FILE *file = fopen("database.txt", "a"); // Open file in append mode
    if (file == NULL)
    {
        perror("Error opening file");
        return;
    }

    // Format the entry as a new line followed by [username]:[password];
    fprintf(file, "\n%s:%s;", username, password); // Combine everything into one line
    printf("User added: %s\n", username);

    fclose(file); // Close file to save changes
}
void create_user_directory(const char *username)
{
    char dir_path[256];  // Buffer to store the directory path
    char file_path[270]; // Increased buffer size to accommodate "/semaphore.txt"

    // Assuming the server directory is "server_dir/"
    snprintf(dir_path, sizeof(dir_path), "server_dir/%s", username);

    // Create the directory with read/write/execute permissions for the owner
    if (mkdir(dir_path, 0700) == 0)
    {
        printf("Directory created: %s\n", dir_path);

        // Create the semaphore.txt file in the new directory
        snprintf(file_path, sizeof(file_path), "%s/semaphore.txt", dir_path);

        FILE *file = fopen(file_path, "w");
        if (file == NULL)
        {
            perror("Error creating semaphore.txt");
        }
        else
        {
            // Write "0;" three times in the file
            fprintf(file, "0;\n0;\n0;\n");

            // Close the file
            fclose(file);

            printf("File created: %s with content '0; 0; 0;'\n", file_path);
        }
    }
    else
    {
        perror("Error creating directory");
    }
}

void *client_handler(void *arg)
{
    int client_socket = *(int *)arg;
    free(arg); // Free the allocated memory

    char getusername[1024] = {0};
    printf("The username is being stored\n");
    if (read(client_socket, getusername, sizeof(getusername)) > 0)
    {
        printf("%s\n", getusername);
    }
    else
    {
        perror("Error reading from socket");
    }
    bool userexist = complete_database(getusername);

    char getpassword[1024] = {0};
    printf("your password has been send\n");
    if (read(client_socket, getpassword, sizeof(getusername)) > 0)
    {
        printf("%s\n", getpassword);
    }
    else
    {
        perror("Error reading from socket");
    }

    if (!userexist)
    {
        printf("Hello");
        add_user(getusername, getpassword);
        create_user_directory(getusername);
    }

    char command[1024] = {0};
    read(client_socket, command, sizeof(command));

    if (strncmp(command, "$UPLOAD$", 8) == 0)
    {
        handle_upload(client_socket, command, getusername);
    }
    else if (strncmp(command, "$DOWNLOAD$", 10) == 0)
    {
        handle_download(client_socket, command, getusername);
    }
    else if (strncmp(command, "$VIEW$", 6) == 0)
    {
        handle_view(client_socket, getusername);
    }

    close(client_socket);
    return NULL;
}

int main()
{
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    client.used_space = 0;

    // Create server socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind the socket to the address
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0)
    {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0)
    {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on 127.0.0.1:%d\n", PORT);

    while (1)
    {
        // Accept a new client connection
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
        {
            perror("Accept failed");
            close(server_fd);
            exit(EXIT_FAILURE);
        }

        // Create a thread to handle the new client
        pthread_t client_thread;
        int *client_socket = malloc(sizeof(int));
        *client_socket = new_socket; // Pass client socket to thread
        if (pthread_create(&client_thread, NULL, client_handler, client_socket) != 0)
        {
            perror("Thread creation failed");
            free(client_socket);
        }

        // Detach the thread to clean up resources automatically when it finishes
        pthread_detach(client_thread);
    }

    close(server_fd);
    return 0;
}